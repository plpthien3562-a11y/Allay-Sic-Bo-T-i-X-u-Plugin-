# AllayDoden

A Sic Bo (Xiu/Tai) dice betting plugin for Spigot/Paper servers, using Vault for the in-game
economy, with a built-in Discord bot ("Jack") so people can bet, and see win/loss activity,
without ever logging into the Minecraft server.

## What changed from DoDen

- **Renamed**: package `com.doden.plugin` → `com.allaydoden.plugin`, main class `DoDen` →
  `AllayDoden`, artifact `AllayDoden`.
- **Direct bet commands**: `/doden bet tai/xiu <amount>` was replaced by `/tai <amount>` and
  `/xiu <amount>`.
- **Configurable payout**: `bet-settings.payout-ratio` in `config.yml` (default `2.0`). Winning
  bets pay `bet * ratio`, minus tax on the profit. Set to `1.95` etc. for a house edge.
- **Main command renamed**: `/doden` → `/asb` (alias `/allaysicbo`; `/dd`, `/playsicbo`, `/doden`
  kept as legacy aliases). Admin command: `/asbadmin` (alias `/allaysicboadmin`; `/dda`,
  `/dodenadmin` kept as legacy aliases).
- **Color code fix**: the help screens for `/asb` and `/asbadmin` used to print raw `&f`/`&e`/`&7`
  codes instead of colors, because they built the message by hand instead of going through
  `MessageManager.color(...)`. Fixed so all in-game text always renders colored. Also removed a
  line in the old color routine that silently deleted every `&r` (reset) code from every message,
  not just the plugin prefix -- a bug that could break formatting resets mid-message.
- **Jack, the Discord bot**: a full Discord integration (see below).

## Discord integration ("Jack")

Enable it in `config.yml`:

```yaml
discord:
  enabled: true
  bot-name: 'Jack'
  bot-token: 'YOUR_BOT_TOKEN'
  guild-id: 'YOUR_GUILD_ID'
  channel-id: 'YOUR_CHANNEL_ID'
  link-code-expiry-seconds: 300
```

1. Create a bot at https://discord.com/developers/applications, invite it to your server with
   permission to read/send messages in the channel you want to use.
2. In the bot's settings, enable the **Message Content Intent** (Bot tab → Privileged Gateway
   Intents) -- without this, Jack cannot read `!tai`/`!xiu`/`!link`/`!unlink` messages.
3. Put the bot token, your Discord server (guild) ID, and the target channel ID into
   `config.yml`, then run `/asbadmin reload` or restart the server.

### Linking a Minecraft account to Discord

- In-game: `/asb link` generates a 6-digit code, valid for 5 minutes (configurable).
- In the configured Discord channel: type `!link <code>` to confirm the link.
- To unlink: type `!unlink` in that same channel.

### Betting from Discord

Once linked, in the configured channel:

- `!tai <amount>` -- bet TAI (high, sum 11-17)
- `!xiu <amount>` -- bet XIU (low, sum 4-10)

Jack announces every bet, win, loss, and session result in that channel -- whether the bet was
placed in-game or from Discord -- so people watching the channel always see what's happening at
the table, and linked Discord users can play the whole game without ever joining the server.

## Building

Requires JDK 17+ and Maven.

```bash
mvn clean package
```

The shaded jar (with Vault/Spigot excluded and JDA + its dependencies bundled and relocated) is
produced at `target/allaydoden-plugin-<version>.jar`. Drop that single jar into your server's
`plugins/` folder alongside Vault and an economy plugin (e.g. EssentialsX).

## Commands & permissions

| Command | Aliases | Permission | Description |
|---|---|---|---|
| `/tai <amount>` | | `doden.use` | Bet TAI (high) |
| `/xiu <amount>` | | `doden.use` | Bet XIU (low) |
| `/asb` | `/allaysicbo`, `/dd`, `/playsicbo`, `/doden` | `doden.use` | Info, rules, toggle, link |
| `/asbadmin` | `/allaysicboadmin`, `/dda`, `/dodenadmin` | `doden.admin` | Reload, changestate, settime, setresult |

`doden.tax.bypass` exempts online players from the profit tax on winnings.

## Notes / assumptions made

A few specifics weren't spelled out in the original request, so reasonable choices were made --
flag any of these if they don't match what you had in mind:

- The Discord linking flow (`/asb link` → `!link <code>` → `!unlink`) follows the `!link %code%`
  wording already present in the original `messages.yml`.
- Discord betting uses prefix commands (`!tai`, `!xiu`) rather than Discord slash commands, to
  match that same existing `!link` convention.
- "Jack bot" was treated as the bot's name/persona (configurable via `discord.bot-name`), not a
  separate feature.
