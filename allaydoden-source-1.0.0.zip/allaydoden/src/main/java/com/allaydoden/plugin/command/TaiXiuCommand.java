/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.command;

import com.allaydoden.plugin.AllayDoden;
import com.allaydoden.plugin.manager.SicBoManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /tai &lt;amount&gt; and /xiu &lt;amount&gt; -- the direct betting commands that replaced
 * "/doden bet tai/xiu &lt;amount&gt;". Which side is bet is determined by which command label
 * was typed, since both are registered to this same executor.
 */
public class TaiXiuCommand implements CommandExecutor {

    private final AllayDoden plugin;

    public TaiXiuCommand(AllayDoden plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().color("player-only"));
            return true;
        }
        if (!player.hasPermission("doden.use")) {
            player.sendMessage(plugin.getMessageManager().color("no-permission"));
            return true;
        }
        if (args.length < 1) {
            player.sendMessage(plugin.getMessageManager().color("bet-usage"));
            return true;
        }

        SicBoManager.BetSide side = command.getName().equalsIgnoreCase("xiu")
                ? SicBoManager.BetSide.XIU
                : SicBoManager.BetSide.TAI;

        double amount;
        try {
            amount = Double.parseDouble(args[0]);
        } catch (NumberFormatException e) {
            player.sendMessage(plugin.getMessageManager().color("invalid-amount",
                    plugin.getMessageManager().ph(
                            "minBet", String.valueOf(plugin.getSicBoManager().getMinBet()),
                            "maxBet", String.valueOf(plugin.getSicBoManager().getMaxBet())
                    )));
            return true;
        }

        SicBoManager.BetResult result = plugin.getSicBoManager().placeBet(player, side, amount);
        switch (result) {
            case LOCKED -> player.sendMessage(plugin.getMessageManager().color("bet-locked"));
            case ALREADY_BET -> player.sendMessage(plugin.getMessageManager().color("already-bet"));
            case AMOUNT_TOO_LOW -> player.sendMessage(plugin.getMessageManager().color("min-bet-exceeded",
                    plugin.getMessageManager().ph("minBet", String.valueOf(plugin.getSicBoManager().getMinBet()))));
            case AMOUNT_TOO_HIGH -> player.sendMessage(plugin.getMessageManager().color("max-bet-exceeded",
                    plugin.getMessageManager().ph("maxBet", String.valueOf(plugin.getSicBoManager().getMaxBet()))));
            case NO_ECONOMY -> player.sendMessage(plugin.getMessageManager().color("no-economy"));
            case INSUFFICIENT_FUNDS -> player.sendMessage(plugin.getMessageManager().color("insufficient-funds",
                    plugin.getMessageManager().ph("balance", plugin.getEconomyManager().format(plugin.getEconomyManager().getBalance(player)))));
            case WITHDRAW_FAILED -> player.sendMessage(plugin.getMessageManager().color("bet-failed"));
            case OK -> { /* bet-success message already sent by SicBoManager */ }
        }
        return true;
    }
}
