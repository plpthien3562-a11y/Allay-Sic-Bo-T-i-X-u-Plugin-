/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.discord;

import com.allaydoden.plugin.manager.SicBoManager;

/**
 * Lets {@link SicBoManager} push bet/win/loss/session events to Jack's Discord channel without
 * depending directly on JDA. When Discord integration is disabled, {@link AllayDodenNoOpAnnouncer}
 * is used instead so the game manager never needs a null check.
 */
public interface DiscordAnnouncer {

    void announceBetPlaced(String playerName, SicBoManager.BetSide side, double amount, boolean viaDiscord);

    void announceWin(String playerName, double payout, boolean viaDiscord);

    void announceLose(String playerName, double amount, boolean viaDiscord);

    void announceSpecial(String playerName, double amount, boolean viaDiscord);

    void announceSessionStart(int session);

    void announceSessionResult(int session, int d1, int d2, int d3, int total, String result);
}
