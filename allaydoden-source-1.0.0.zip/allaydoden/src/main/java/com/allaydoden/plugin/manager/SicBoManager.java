/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.manager;

import com.allaydoden.plugin.AllayDoden;
import com.allaydoden.plugin.discord.DiscordAnnouncer;
import com.allaydoden.plugin.discord.NoOpAnnouncer;
import com.allaydoden.plugin.economy.EconomyManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;
import java.util.stream.Collectors;

public class SicBoManager {

    public enum GameState { PLAYING, PAUSING }
    public enum BetSide { XIU, TAI }

    public record Bet(UUID playerId, String playerName, BetSide side, double amount) {}

    /** Why a bet placement failed -- lets callers (in-game command or Discord) render their own message. */
    public enum BetResult {
        OK, LOCKED, ALREADY_BET, AMOUNT_TOO_LOW, AMOUNT_TOO_HIGH, NO_ECONOMY, INSUFFICIENT_FUNDS, WITHDRAW_FAILED
    }

    private final AllayDoden plugin;
    private EconomyManager economy;
    private DiscordAnnouncer discordAnnouncer = new NoOpAnnouncer();

    private int sessionNumber = 0;
    private int timeRemaining;
    private int timePerSession;
    private GameState state = GameState.PLAYING;
    private final Map<UUID, Bet> bets = new HashMap<>();
    private BossBar bossBar;
    private BukkitRunnable task;

    private int forcedD1 = -1, forcedD2 = -1, forcedD3 = -1;

    private int minBet, maxBet, taxPercent, disableWhileRemaining;
    private double payoutRatio;
    private boolean disableSpecial;

    public SicBoManager(AllayDoden plugin) {
        this.plugin = plugin;
        loadConfig();
    }

    private void loadConfig() {
        economy = plugin.getEconomyManager();
        timePerSession = plugin.getConfig().getInt("task.time-per-session", 125);
        minBet = plugin.getConfig().getInt("bet-settings.min-bet", 500);
        maxBet = plugin.getConfig().getInt("bet-settings.max-bet", 1000000);
        taxPercent = plugin.getConfig().getInt("bet-settings.tax", 0);
        payoutRatio = plugin.getConfig().getDouble("bet-settings.payout-ratio", 2.0);
        disableWhileRemaining = plugin.getConfig().getInt("bet-settings.disable-while-remaining", 15);
        disableSpecial = plugin.getConfig().getBoolean("bet-settings.disable-special", false);
    }

    public void reload() {
        loadConfig();
    }

    public void setDiscordAnnouncer(DiscordAnnouncer announcer) {
        this.discordAnnouncer = announcer != null ? announcer : new NoOpAnnouncer();
    }

    public double getPayoutRatio() {
        return payoutRatio;
    }

    public void start() {
        startNewSession();
    }

    public void stop() {
        if (task != null) task.cancel();
        if (bossBar != null) {
            bossBar.removeAll();
            bossBar = null;
        }
    }

    public void startNewSession() {
        sessionNumber++;
        bets.clear();
        timeRemaining = timePerSession;
        state = GameState.PLAYING;

        createBossBar();
        announceSessionStart();

        task = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        };
        task.runTaskTimer(plugin, 0L, 20L);
    }

    private void tick() {
        timeRemaining--;

        updateBossBar();

        if (timeRemaining <= 0) {
            endSession();
        }
    }

    private void endSession() {
        task.cancel();

        int d1, d2, d3;
        if (forcedD1 > 0 && forcedD2 > 0 && forcedD3 > 0) {
            d1 = forcedD1; d2 = forcedD2; d3 = forcedD3;
            forcedD1 = forcedD2 = forcedD3 = -1;
        } else {
            d1 = rollDie();
            d2 = rollDie();
            d3 = rollDie();
        }

        if (disableSpecial) {
            int sum = d1 + d2 + d3;
            if (sum == 3) { d1++; }
            else if (sum == 18) { d1--; }
        }

        int total = d1 + d2 + d3;
        boolean isSpecial = (total == 3 || total == 18);
        BetSide winningSide = total <= 10 ? BetSide.XIU : BetSide.TAI;

        updateBossBarResult(d1, d2, d3, total, isSpecial, winningSide);

        processPayouts(winningSide, isSpecial);

        String resultName = isSpecial ? "SPECIAL" : (winningSide == BetSide.XIU ? "XIU (Low)" : "TAI (High)");
        discordAnnouncer.announceSessionResult(sessionNumber, d1, d2, d3, total, resultName);

        int reloadTime = plugin.getConfig().getInt("boss-bar.reloading.time", 5);
        Bukkit.getScheduler().runTaskLater(plugin, this::startNewSession, reloadTime * 20L);
    }

    private void processPayouts(BetSide winningSide, boolean isSpecial) {
        if (!economy.isEnabled()) return;

        for (Bet bet : bets.values()) {
            // Use OfflinePlayer for the economy transaction so Discord-linked players who are not
            // currently logged in still get paid. In-game messages/sounds only fire if they're online.
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(bet.playerId());
            Player onlinePlayer = offlinePlayer.isOnline() ? (Player) offlinePlayer : null;
            boolean viaDiscord = onlinePlayer == null;

            boolean bypassTax = onlinePlayer != null && onlinePlayer.hasPermission("doden.tax.bypass");
            int effectiveTax = bypassTax ? 0 : taxPercent;

            if (isSpecial) {
                if (onlinePlayer != null) {
                    playSound(onlinePlayer, false);
                    onlinePlayer.sendMessage(plugin.getMessageManager().color("special-message",
                            plugin.getMessageManager().ph("bet", economy.format(bet.amount()))));
                }
                discordAnnouncer.announceSpecial(bet.playerName(), bet.amount(), viaDiscord);
            } else if (bet.side() == winningSide) {
                double grossReturn = bet.amount() * payoutRatio;
                double profit = grossReturn - bet.amount();
                double taxAmount = profit * effectiveTax / 100.0;
                double payout = Math.round(grossReturn - taxAmount);
                economy.deposit(offlinePlayer, payout);
                if (onlinePlayer != null) {
                    playSound(onlinePlayer, true);
                    onlinePlayer.sendMessage(plugin.getMessageManager().color("win-message",
                            plugin.getMessageManager().ph("payout", economy.format(payout))));
                }
                discordAnnouncer.announceWin(bet.playerName(), payout, viaDiscord);
            } else {
                if (onlinePlayer != null) {
                    playSound(onlinePlayer, false);
                    onlinePlayer.sendMessage(plugin.getMessageManager().color("lose-message",
                            plugin.getMessageManager().ph("bet", economy.format(bet.amount()))));
                }
                discordAnnouncer.announceLose(bet.playerName(), bet.amount(), viaDiscord);
            }
        }
    }

    private int rollDie() {
        return new Random().nextInt(6) + 1;
    }

    // ── Betting ───────────────────────────────────────────────────────────

    /**
     * Places a bet for any {@link OfflinePlayer} -- online (typed /tai in-game) or offline
     * (typed !tai in Discord, resolved through a link). Caller is responsible for translating
     * the {@link BetResult} into a player-facing or Discord-facing message.
     */
    public BetResult placeBet(OfflinePlayer player, BetSide side, double amount) {
        if (state != GameState.PLAYING || timeRemaining <= disableWhileRemaining) {
            return BetResult.LOCKED;
        }
        if (bets.containsKey(player.getUniqueId())) {
            return BetResult.ALREADY_BET;
        }
        if (amount < minBet) {
            return BetResult.AMOUNT_TOO_LOW;
        }
        if (amount > maxBet) {
            return BetResult.AMOUNT_TOO_HIGH;
        }
        if (!economy.isEnabled()) {
            return BetResult.NO_ECONOMY;
        }
        if (!economy.has(player, amount)) {
            return BetResult.INSUFFICIENT_FUNDS;
        }
        if (!economy.withdraw(player, amount)) {
            return BetResult.WITHDRAW_FAILED;
        }

        String playerName = player.getName() != null ? player.getName() : "Unknown";
        bets.put(player.getUniqueId(), new Bet(player.getUniqueId(), playerName, side, amount));

        boolean viaDiscord = !(player instanceof Player) || !player.isOnline();
        if (player instanceof Player online && player.isOnline()) {
            String sideName = side == BetSide.XIU ? "XIU (Low)" : "TAI (High)";
            online.sendMessage(plugin.getMessageManager().color("bet-success",
                    plugin.getMessageManager().ph("side", sideName, "amount", economy.format(amount))));
        }
        discordAnnouncer.announceBetPlaced(playerName, side, amount, viaDiscord);
        return BetResult.OK;
    }

    // ── BossBar ───────────────────────────────────────────────────────────
    private void createBossBar() {
        if (bossBar != null) bossBar.removeAll();
        boolean enabled = plugin.getConfig().getBoolean("boss-bar.enabled", true);
        if (!enabled) return;
        bossBar = Bukkit.createBossBar(
                plugin.getMessageManager().color("bossbar-betting",
                        plugin.getMessageManager().ph(
                                "session", String.valueOf(sessionNumber),
                                "time", String.valueOf(timeRemaining),
                                "xiuBet", getTotalBet(BetSide.XIU),
                                "taiBet", getTotalBet(BetSide.TAI)
                        )),
                BarColor.YELLOW,
                BarStyle.SEGMENTED_10
        );
        bossBar.setProgress(1.0);
        bossBar.setVisible(true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (plugin.getConfig().getBoolean("toggle-settings.auto-toggle", true)) {
                bossBar.addPlayer(p);
            }
        }
    }

    private void updateBossBar() {
        if (bossBar == null) return;
        double progress = Math.max(0.0, Math.min(1.0, (double) timeRemaining / timePerSession));
        bossBar.setProgress(progress);

        if (timeRemaining <= disableWhileRemaining) {
            bossBar.setColor(BarColor.BLUE);
            bossBar.setTitle(plugin.getMessageManager().color("bossbar-locked",
                    plugin.getMessageManager().ph("session", String.valueOf(sessionNumber))));
        } else {
            bossBar.setColor(BarColor.YELLOW);
            bossBar.setTitle(plugin.getMessageManager().color("bossbar-betting",
                    plugin.getMessageManager().ph(
                            "session", String.valueOf(sessionNumber),
                            "time", String.valueOf(timeRemaining),
                            "xiuBet", getTotalBet(BetSide.XIU),
                            "taiBet", getTotalBet(BetSide.TAI)
                    )));
        }
    }

    private void updateBossBarResult(int d1, int d2, int d3, int total, boolean isSpecial, BetSide winningSide) {
        if (bossBar == null) return;
        Map<String, String> ph = plugin.getMessageManager().ph("total", String.valueOf(total));
        if (isSpecial) {
            bossBar.setColor(BarColor.PURPLE);
            bossBar.setTitle(plugin.getMessageManager().color("bossbar-result-special", ph));
        } else if (winningSide == BetSide.XIU) {
            bossBar.setColor(BarColor.GREEN);
            bossBar.setTitle(plugin.getMessageManager().color("bossbar-result-xiu", ph));
        } else {
            bossBar.setColor(BarColor.RED);
            bossBar.setTitle(plugin.getMessageManager().color("bossbar-result-tai", ph));
        }
        bossBar.setProgress(1.0);
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private String getTotalBet(BetSide side) {
        double total = bets.values().stream()
                .filter(b -> b.side() == side)
                .mapToDouble(Bet::amount)
                .sum();
        return economy != null ? economy.format(total) : String.valueOf((int) total);
    }

    private void playSound(Player player, boolean won) {
        String path = won ? "sound.win" : "sound.lose";
        if (!plugin.getConfig().getBoolean(path + ".enabled", true)) return;
        String soundName = plugin.getConfig().getString(path + ".sound-name", won ? "ENTITY_PLAYER_LEVELUP" : "ENTITY_VILLAGER_NO");
        float volume = (float) plugin.getConfig().getDouble(path + ".volume", 1.0);
        float pitch = (float) plugin.getConfig().getDouble(path + ".pitch", 1.0);
        try {
            Sound sound = Sound.valueOf(soundName);
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ignored) {
        }
    }

    private void announceSessionStart() {
        String msg = plugin.getMessageManager().color("session-start",
                plugin.getMessageManager().ph("session", String.valueOf(sessionNumber)));
        Bukkit.getOnlinePlayers().forEach(p -> p.sendMessage(msg));
        discordAnnouncer.announceSessionStart(sessionNumber);
    }

    // ── Getters ───────────────────────────────────────────────────────────
    public int getSessionNumber() { return sessionNumber; }
    public int getTimeRemaining() { return timeRemaining; }
    public GameState getState() { return state; }
    public Map<UUID, Bet> getBets() { return bets; }

    public int getBettorCount(BetSide side) {
        return (int) bets.values().stream().filter(b -> b.side() == side).count();
    }

    public double getTotalBetAmount(BetSide side) {
        return bets.values().stream()
                .filter(b -> b.side() == side)
                .mapToDouble(Bet::amount)
                .sum();
    }

    public double getTotalBetAmount() {
        return bets.values().stream().mapToDouble(Bet::amount).sum();
    }

    public int getMinBet() { return minBet; }
    public int getMaxBet() { return maxBet; }

    public BossBar getBossBar() { return bossBar; }

    public void setForcedResult(int d1, int d2, int d3) {
        forcedD1 = d1; forcedD2 = d2; forcedD3 = d3;
    }

    public void changeState() {
        state = (state == GameState.PLAYING) ? GameState.PAUSING : GameState.PLAYING;
    }

    public void setTime(int seconds) {
        timeRemaining = seconds;
    }

    public List<Bet> getSortedBets(String sortMode) {
        return switch (sortMode.toLowerCase()) {
            case "tai" -> bets.values().stream().filter(b -> b.side() == BetSide.TAI).collect(Collectors.toList());
            case "xiu" -> bets.values().stream().filter(b -> b.side() == BetSide.XIU).collect(Collectors.toList());
            case "highest" -> bets.values().stream().sorted((a, b) -> Double.compare(b.amount(), a.amount())).collect(Collectors.toList());
            case "lowest" -> bets.values().stream().sorted(Comparator.comparingDouble(Bet::amount)).collect(Collectors.toList());
            default -> new ArrayList<>(bets.values());
        };
    }
}
