/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.discord;

import com.allaydoden.plugin.AllayDoden;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles the /asb link -&gt; !link &lt;code&gt; -&gt; !unlink flow that lets a Discord user play
 * without ever logging into the Minecraft server. Confirmed links are persisted to links.yml;
 * pending (unconfirmed) codes are kept in memory only, since they're short-lived.
 */
public class LinkManager {

    private record PendingLink(UUID minecraftId, String minecraftName, long expiresAt) {}

    private final AllayDoden plugin;
    private final File file;
    private final Map<String, PendingLink> pendingCodes = new ConcurrentHashMap<>();
    /** discordUserId -> minecraft UUID */
    private final Map<String, UUID> linksByDiscordId = new HashMap<>();
    /** minecraft UUID -> discordUserId */
    private final Map<UUID, String> linksByMinecraftId = new HashMap<>();
    /** discordUserId -> discord tag/username, kept only for display in in-game messages */
    private final Map<String, String> discordNames = new HashMap<>();

    public LinkManager(AllayDoden plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "links.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        FileConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (yaml.isConfigurationSection("links")) {
            for (String discordId : yaml.getConfigurationSection("links").getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(yaml.getString("links." + discordId + ".uuid"));
                    String discordName = yaml.getString("links." + discordId + ".discord-name", discordId);
                    linksByDiscordId.put(discordId, uuid);
                    linksByMinecraftId.put(uuid, discordId);
                    discordNames.put(discordId, discordName);
                } catch (IllegalArgumentException ignored) {
                    // Corrupt entry, skip it.
                }
            }
        }
    }

    private void save() {
        FileConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<String, UUID> entry : linksByDiscordId.entrySet()) {
            yaml.set("links." + entry.getKey() + ".uuid", entry.getValue().toString());
            yaml.set("links." + entry.getKey() + ".discord-name", discordNames.getOrDefault(entry.getKey(), entry.getKey()));
        }
        try {
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Failed to save links.yml: " + e.getMessage());
        }
    }

    /** Generates a fresh 6-digit code for the given in-game player, replacing any code they already had pending. */
    public String createCode(OfflinePlayer player) {
        pendingCodes.values().removeIf(p -> p.minecraftId.equals(player.getUniqueId()));
        pendingCodes.entrySet().removeIf(e -> e.getValue().minecraftId.equals(player.getUniqueId()));

        int expirySeconds = plugin.getConfig().getInt("discord.link-code-expiry-seconds", 300);
        String code;
        do {
            code = String.format("%06d", new Random().nextInt(1_000_000));
        } while (pendingCodes.containsKey(code));

        pendingCodes.put(code, new PendingLink(player.getUniqueId(), player.getName(), System.currentTimeMillis() + expirySeconds * 1000L));
        return code;
    }

    public enum LinkOutcome { SUCCESS, INVALID_OR_EXPIRED, ALREADY_LINKED }

    /** Confirms a pending code for a given Discord user. Returns the linked Minecraft player name on success. */
    public LinkAttempt confirmLink(String discordUserId, String discordDisplayName, String code) {
        if (linksByDiscordId.containsKey(discordUserId)) {
            String linkedName = getLinkedPlayerName(discordUserId);
            return new LinkAttempt(LinkOutcome.ALREADY_LINKED, linkedName);
        }

        PendingLink pending = pendingCodes.get(code);
        if (pending == null || pending.expiresAt < System.currentTimeMillis()) {
            pendingCodes.remove(code);
            return new LinkAttempt(LinkOutcome.INVALID_OR_EXPIRED, null);
        }

        pendingCodes.remove(code);
        linksByDiscordId.put(discordUserId, pending.minecraftId);
        linksByMinecraftId.put(pending.minecraftId, discordUserId);
        discordNames.put(discordUserId, discordDisplayName);
        save();
        return new LinkAttempt(LinkOutcome.SUCCESS, pending.minecraftName);
    }

    public record LinkAttempt(LinkOutcome outcome, String playerName) {}

    /** Removes the link for a Discord user. Returns the unlinked Minecraft player name, or null if not linked. */
    public String unlink(String discordUserId) {
        UUID uuid = linksByDiscordId.remove(discordUserId);
        if (uuid == null) return null;
        linksByMinecraftId.remove(uuid);
        String name = discordNames.remove(discordUserId);
        save();
        return getPlayerNameOrFallback(uuid, name);
    }

    private String getPlayerNameOrFallback(UUID uuid, String fallback) {
        String name = plugin.getServer().getOfflinePlayer(uuid).getName();
        return name != null ? name : fallback;
    }

    public boolean isDiscordUserLinked(String discordUserId) {
        return linksByDiscordId.containsKey(discordUserId);
    }

    public UUID getLinkedMinecraftId(String discordUserId) {
        return linksByDiscordId.get(discordUserId);
    }

    public String getLinkedPlayerName(String discordUserId) {
        UUID uuid = linksByDiscordId.get(discordUserId);
        if (uuid == null) return null;
        return getPlayerNameOrFallback(uuid, null);
    }

    public String getLinkedDiscordId(UUID minecraftId) {
        return linksByMinecraftId.get(minecraftId);
    }
}
