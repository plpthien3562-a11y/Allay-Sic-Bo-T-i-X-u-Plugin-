/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin;

import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MessageManager {

    private final AllayDoden plugin;
    private FileConfiguration messages;
    private String prefix;

    public MessageManager(AllayDoden plugin) {
        this.plugin = plugin;
        load();
    }

    public void load() {
        String locale = plugin.getConfig().getString("locale", "en");
        File file = new File(plugin.getDataFolder(), "messages_" + locale + ".yml");
        if (!file.exists()) {
            file = new File(plugin.getDataFolder(), "messages.yml");
        }
        messages = YamlConfiguration.loadConfiguration(file);
        prefix = messages.getString("prefix", "&6[AllayDoden]&r");
    }

    public void reload() {
        load();
    }

    public String get(String key) {
        return messages.getString(key, "&cMissing message: " + key);
    }

    public String get(String key, Map<String, String> placeholders) {
        String msg = get(key);
        if (placeholders != null) {
            for (Map.Entry<String, String> entry : placeholders.entrySet()) {
                msg = msg.replace("%" + entry.getKey() + "%", entry.getValue());
            }
        }
        return msg;
    }

    /**
     * Translates '&' color codes to Minecraft's section-sign codes. Every message that reaches a
     * player or console MUST go through this method -- sending raw '&' codes displays the literal
     * text (e.g. "&f/tai 100") instead of colored text.
     */
    public String color(String msg) {
        if (msg == null) return "";
        msg = msg.replace("%prefix%", prefix);
        msg = ChatColor.translateAlternateColorCodes('&', msg);
        return msg;
    }

    public String color(String key, Map<String, String> placeholders) {
        return color(get(key, placeholders));
    }

    /**
     * Strips all color codes -- used for plain-text contexts that don't render Minecraft color
     * codes, such as Discord messages.
     */
    public String plain(String key, Map<String, String> placeholders) {
        return ChatColor.stripColor(color(key, placeholders));
    }

    public Map<String, String> ph(Object... pairs) {
        Map<String, String> map = new HashMap<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            map.put(String.valueOf(pairs[i]), String.valueOf(pairs[i + 1]));
        }
        return map;
    }
}
