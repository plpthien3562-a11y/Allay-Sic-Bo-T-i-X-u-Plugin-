/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.discord;

import com.allaydoden.plugin.AllayDoden;
import com.allaydoden.plugin.manager.SicBoManager;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

/**
 * "Jack" -- the Discord dealer bot. Reads !tai / !xiu / !link / !unlink from the configured
 * channel and announces bet/win/loss/session activity there, so players can play AllayDoden
 * entirely from Discord without ever logging into the Minecraft server.
 *
 * All JDA callbacks run on JDA's own threads, never the server thread. Anything that touches
 * Bukkit state (the economy, SicBoManager, scheduling in-game messages) is bounced back onto the
 * main thread via {@code Bukkit.getScheduler().runTask(...)}.
 */
public class DiscordManager implements DiscordAnnouncer {

    private final AllayDoden plugin;
    private final LinkManager linkManager;
    private JDA jda;
    private String channelId;
    private String botName;

    public DiscordManager(AllayDoden plugin, LinkManager linkManager) {
        this.plugin = plugin;
        this.linkManager = linkManager;
    }

    public boolean start() {
        if (!plugin.getConfig().getBoolean("discord.enabled", false)) {
            return false;
        }
        String token = plugin.getConfig().getString("discord.bot-token", "");
        channelId = plugin.getConfig().getString("discord.channel-id", "");
        botName = plugin.getConfig().getString("discord.bot-name", "Jack");

        if (token.isBlank() || channelId.isBlank()) {
            plugin.getLogger().warning("Discord integration is enabled but bot-token or channel-id is missing in config.yml.");
            return false;
        }

        try {
            jda = JDABuilder.createDefault(token)
                    .enableIntents(GatewayIntent.GUILD_MESSAGES, GatewayIntent.MESSAGE_CONTENT)
                    .setActivity(Activity.playing("Sic Bo | !tai <amount> or !xiu <amount>"))
                    .addEventListeners(new JackListener())
                    .build();
            jda.awaitReady();
            plugin.getLogger().info(botName + " connected to Discord.");
            return true;
        } catch (Exception e) {
            plugin.getLogger().severe("Failed to start the Discord bot (" + botName + "): " + e.getMessage());
            jda = null;
            return false;
        }
    }

    public void stop() {
        if (jda != null) {
            jda.shutdown();
            try {
                jda.awaitShutdown(10, TimeUnit.SECONDS);
            } catch (InterruptedException ignored) {
            }
            jda = null;
        }
    }

    private void send(String message) {
        if (jda == null) return;
        MessageChannel channel = jda.getChannelById(MessageChannel.class, channelId);
        if (channel != null) {
            channel.sendMessage(message).queue(s -> {}, f -> plugin.getLogger().warning("Failed to send Discord message: " + f.getMessage()));
        }
    }

    private String plain(String key, Map<String, String> placeholders) {
        return plugin.getMessageManager().plain(key, placeholders);
    }

    // ── DiscordAnnouncer (called from the server thread by SicBoManager) ───
    @Override
    public void announceBetPlaced(String playerName, SicBoManager.BetSide side, double amount, boolean viaDiscord) {
        if (!viaDiscord) {
            // Only announce bets placed in-game; bets placed via Discord already get a direct reply.
            send(plain("discord-jack-bet-placed", plugin.getMessageManager().ph(
                    "player", playerName, "amount", plugin.getEconomyManager().format(amount),
                    "side", side == SicBoManager.BetSide.TAI ? "TAI (High)" : "XIU (Low)")));
        }
    }

    @Override
    public void announceWin(String playerName, double payout, boolean viaDiscord) {
        send(plain("discord-jack-win", plugin.getMessageManager().ph(
                "player", playerName, "payout", plugin.getEconomyManager().format(payout))));
    }

    @Override
    public void announceLose(String playerName, double amount, boolean viaDiscord) {
        send(plain("discord-jack-lose", plugin.getMessageManager().ph(
                "player", playerName, "bet", plugin.getEconomyManager().format(amount))));
    }

    @Override
    public void announceSpecial(String playerName, double amount, boolean viaDiscord) {
        send(plain("discord-jack-special", plugin.getMessageManager().ph(
                "player", playerName, "bet", plugin.getEconomyManager().format(amount))));
    }

    @Override
    public void announceSessionStart(int session) {
        send(plain("discord-jack-session-start", plugin.getMessageManager().ph("session", String.valueOf(session))));
    }

    @Override
    public void announceSessionResult(int session, int d1, int d2, int d3, int total, String result) {
        send(plain("discord-jack-session-result", plugin.getMessageManager().ph(
                "session", String.valueOf(session), "d1", String.valueOf(d1), "d2", String.valueOf(d2),
                "d3", String.valueOf(d3), "total", String.valueOf(total), "result", result)));
    }

    // ── Incoming Discord messages ───────────────────────────────────────────
    private class JackListener extends ListenerAdapter {
        @Override
        public void onMessageReceived(MessageReceivedEvent event) {
            if (event.getAuthor().isBot() || event.getAuthor().isSystem()) return;
            if (!event.getChannel().getId().equals(channelId)) return;

            String content = event.getMessage().getContentRaw().trim();
            String discordUserId = event.getAuthor().getId();
            String discordDisplayName = event.getAuthor().getName();
            MessageChannel channel = event.getChannel();

            if (content.equalsIgnoreCase("!unlink")) {
                handleUnlink(channel, discordUserId);
            } else if (content.toLowerCase().startsWith("!link ")) {
                handleLink(channel, discordUserId, discordDisplayName, content.substring(6).trim());
            } else if (content.toLowerCase().startsWith("!tai")) {
                handleBet(channel, discordUserId, SicBoManager.BetSide.TAI, content.substring(4).trim());
            } else if (content.toLowerCase().startsWith("!xiu")) {
                handleBet(channel, discordUserId, SicBoManager.BetSide.XIU, content.substring(4).trim());
            }
        }

        private void handleLink(MessageChannel channel, String discordUserId, String discordDisplayName, String code) {
            // links.yml I/O is cheap and thread-safe enough here, but we still hop onto the main
            // thread since LinkManager reads OfflinePlayer names from Bukkit.
            Bukkit.getScheduler().runTask(plugin, () -> {
                LinkManager.LinkAttempt attempt = linkManager.confirmLink(discordUserId, discordDisplayName, code);
                String playerName = attempt.playerName() == null ? "player" : attempt.playerName();
                String reply = switch (attempt.outcome()) {
                    case SUCCESS -> plain("discord-jack-link-success",
                            plugin.getMessageManager().ph("player", playerName));
                    case ALREADY_LINKED -> plain("discord-jack-link-already-used",
                            plugin.getMessageManager().ph("player", playerName));
                    case INVALID_OR_EXPIRED -> plain("discord-jack-link-invalid", Map.of());
                };
                // Previously the queue() call had no failure handler, so a rejected send
                // (missing send permission, transient JDA error) silently swallowed the
                // verification confirmation. Log both outcomes so a successful verify
                // always produces a visible signal.
                channel.sendMessage(reply).queue(
                        s -> {
                            if (attempt.outcome() == LinkManager.LinkOutcome.SUCCESS) {
                                plugin.getLogger().info("Discord link verified for " + playerName + " (" + discordDisplayName + ").");
                            }
                        },
                        f -> plugin.getLogger().warning("Failed to send Discord link reply for " + discordDisplayName + ": " + f.getMessage())
                );
            });
        }

        private void handleUnlink(MessageChannel channel, String discordUserId) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                String playerName = linkManager.unlink(discordUserId);
                if (playerName != null) {
                    channel.sendMessage(plain("discord-jack-unlink-success", plugin.getMessageManager().ph("player", playerName))).queue();
                } else {
                    channel.sendMessage(plain("discord-jack-unlink-not-linked", Map.of())).queue();
                }
            });
        }

        private void handleBet(MessageChannel channel, String discordUserId, SicBoManager.BetSide side, String amountStr) {
            if (!linkManager.isDiscordUserLinked(discordUserId)) {
                channel.sendMessage(plain("discord-jack-not-linked", Map.of())).queue();
                return;
            }
            double amount;
            try {
                amount = Double.parseDouble(amountStr);
            } catch (NumberFormatException e) {
                channel.sendMessage(plain("discord-jack-invalid-amount", Map.of())).queue();
                return;
            }

            Bukkit.getScheduler().runTask(plugin, () -> {
                UUID uuid = linkManager.getLinkedMinecraftId(discordUserId);
                OfflinePlayer player = Bukkit.getOfflinePlayer(uuid);
                SicBoManager.BetResult result = plugin.getSicBoManager().placeBet(player, side, amount);
                if (result != SicBoManager.BetResult.OK) {
                    channel.sendMessage(plain("discord-jack-bet-error", plugin.getMessageManager().ph(
                            "reason", describe(result)))).queue();
                }
                // On success, announceBetPlaced already fired the confirmation via the announcer.
            });
        }

        private String describe(SicBoManager.BetResult result) {
            return switch (result) {
                case LOCKED -> "Betting is locked for this session. Wait for the next one.";
                case ALREADY_BET -> "You already placed a bet this session.";
                case AMOUNT_TOO_LOW -> "That amount is below the minimum bet.";
                case AMOUNT_TOO_HIGH -> "That amount is above the maximum bet.";
                case NO_ECONOMY -> "No economy provider is configured on the server.";
                case INSUFFICIENT_FUNDS -> "You don't have enough money for that bet.";
                case WITHDRAW_FAILED -> "The bet failed unexpectedly.";
                default -> "Unknown error.";
            };
        }
    }
}
