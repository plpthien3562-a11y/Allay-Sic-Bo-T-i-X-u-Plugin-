/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.command;

import com.allaydoden.plugin.AllayDoden;
import com.allaydoden.plugin.manager.SicBoManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * /asb (aliases: allaysicbo, dd, playsicbo, doden) -- info, rules, toggle, link.
 * Betting itself now lives in {@link TaiXiuCommand} (/tai, /xiu).
 */
public class SicBoCommand implements CommandExecutor, TabCompleter {

    private final AllayDoden plugin;

    public SicBoCommand(AllayDoden plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(plugin.getMessageManager().color("player-only"));
            return true;
        }
        if (!player.hasPermission("doden.use")) {
            player.sendMessage(plugin.getMessageManager().color("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "info" -> handleInfo(player);
            case "rules" -> handleRules(player);
            case "toggle" -> handleToggle(player);
            case "link" -> handleLink(player);
            default -> sendHelp(player);
        }
        return true;
    }

    private void handleInfo(Player player) {
        SicBoManager sb = plugin.getSicBoManager();
        player.sendMessage(plugin.getMessageManager().color("info-header",
                plugin.getMessageManager().ph("session", String.valueOf(sb.getSessionNumber()))));
        player.sendMessage(plugin.getMessageManager().color("info-time",
                plugin.getMessageManager().ph("time", String.valueOf(sb.getTimeRemaining()))));
        player.sendMessage(plugin.getMessageManager().color("info-state",
                plugin.getMessageManager().ph("state", sb.getState().name())));
        player.sendMessage(plugin.getMessageManager().color("info-xiu",
                plugin.getMessageManager().ph(
                        "xiuCount", String.valueOf(sb.getBettorCount(SicBoManager.BetSide.XIU)),
                        "xiuBet", plugin.getEconomyManager().format(sb.getTotalBetAmount(SicBoManager.BetSide.XIU))
                )));
        player.sendMessage(plugin.getMessageManager().color("info-tai",
                plugin.getMessageManager().ph(
                        "taiCount", String.valueOf(sb.getBettorCount(SicBoManager.BetSide.TAI)),
                        "taiBet", plugin.getEconomyManager().format(sb.getTotalBetAmount(SicBoManager.BetSide.TAI))
                )));
        player.sendMessage(plugin.getMessageManager().color("info-total",
                plugin.getMessageManager().ph("totalBet", plugin.getEconomyManager().format(sb.getTotalBetAmount()))));

        if (sb.getBets().isEmpty()) {
            player.sendMessage(plugin.getMessageManager().color("info-no-bettors"));
        } else {
            player.sendMessage(plugin.getMessageManager().color("info-bettors"));
            for (SicBoManager.Bet bet : sb.getBets().values()) {
                String sideColor = bet.side() == SicBoManager.BetSide.XIU ? "&a" : "&c";
                String sideName = bet.side() == SicBoManager.BetSide.XIU ? "XIU" : "TAI";
                player.sendMessage(plugin.getMessageManager().color("info-bettor",
                        plugin.getMessageManager().ph(
                                "player", bet.playerName(),
                                "sideColor", sideColor,
                                "side", sideName,
                                "amount", plugin.getEconomyManager().format(bet.amount())
                        )));
            }
        }
    }

    private void handleRules(Player player) {
        String ratio = String.valueOf(plugin.getSicBoManager().getPayoutRatio());
        for (int i = 1; i <= 6; i++) {
            player.sendMessage(plugin.getMessageManager().color("rules-line" + i,
                    plugin.getMessageManager().ph("ratio", ratio)));
        }
    }

    private void handleToggle(Player player) {
        var bossBar = plugin.getSicBoManager().getBossBar();
        if (bossBar == null) {
            player.sendMessage(plugin.getMessageManager().color("toggle-off"));
            return;
        }
        if (bossBar.getPlayers().contains(player)) {
            bossBar.removePlayer(player);
            player.sendMessage(plugin.getMessageManager().color("toggle-off"));
        } else {
            bossBar.addPlayer(player);
            player.sendMessage(plugin.getMessageManager().color("toggle-on"));
        }
    }

    private void handleLink(Player player) {
        if (!plugin.getConfig().getBoolean("discord.enabled", false)) {
            player.sendMessage(plugin.getMessageManager().color("discord-not-configured"));
            return;
        }

        String existingDiscordId = plugin.getLinkManager().getLinkedDiscordId(player.getUniqueId());
        if (existingDiscordId != null) {
            player.sendMessage(plugin.getMessageManager().color("discord-already-linked",
                    plugin.getMessageManager().ph(
                            "discordUser", existingDiscordId,
                            "channel", plugin.getConfig().getString("discord.channel-id", ""))));
            return;
        }

        String code = plugin.getLinkManager().createCode(player);
        int expirySeconds = plugin.getConfig().getInt("discord.link-code-expiry-seconds", 300);
        player.sendMessage(plugin.getMessageManager().color("discord-link-prompt",
                plugin.getMessageManager().ph(
                        "code", code,
                        "channel", plugin.getConfig().getString("discord.channel-id", ""),
                        "minutes", String.valueOf(Math.max(1, expirySeconds / 60)))));
    }

    private void sendHelp(Player player) {
        player.sendMessage(plugin.getMessageManager().color("help-header"));
        player.sendMessage(plugin.getMessageManager().color("help-tai"));
        player.sendMessage(plugin.getMessageManager().color("help-xiu"));
        player.sendMessage(plugin.getMessageManager().color("help-info"));
        player.sendMessage(plugin.getMessageManager().color("help-rules"));
        player.sendMessage(plugin.getMessageManager().color("help-toggle"));
        player.sendMessage(plugin.getMessageManager().color("help-link"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.addAll(List.of("info", "rules", "toggle", "link"));
        }
        return completions.stream()
                .filter(c -> c.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .toList();
    }
}
