/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin;

import com.allaydoden.plugin.command.SicBoAdminCommand;
import com.allaydoden.plugin.command.SicBoCommand;
import com.allaydoden.plugin.command.TaiXiuCommand;
import com.allaydoden.plugin.discord.DiscordManager;
import com.allaydoden.plugin.discord.LinkManager;
import com.allaydoden.plugin.economy.EconomyManager;
import com.allaydoden.plugin.manager.SicBoManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public class AllayDoden extends JavaPlugin {

    private static AllayDoden instance;

    private EconomyManager economyManager;
    private SicBoManager sicBoManager;
    private MessageManager messageManager;
    private LinkManager linkManager;
    private DiscordManager discordManager;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        saveResource("messages.yml", false);

        messageManager = new MessageManager(this);

        economyManager = new EconomyManager(this);
        if (!economyManager.setup()) {
            getLogger().warning(messageManager.color(messageManager.get("vault-not-found")));
        } else {
            getLogger().info("Vault economy hooked: " + economyManager.getEconomyName());
        }

        sicBoManager = new SicBoManager(this);

        linkManager = new LinkManager(this);
        discordManager = new DiscordManager(this, linkManager);
        if (discordManager.start()) {
            sicBoManager.setDiscordAnnouncer(discordManager);
        }

        sicBoManager.start();

        Objects.requireNonNull(getCommand("asb")).setExecutor(new SicBoCommand(this));
        Objects.requireNonNull(getCommand("asb")).setTabCompleter(new SicBoCommand(this));
        Objects.requireNonNull(getCommand("asbadmin")).setExecutor(new SicBoAdminCommand(this));
        Objects.requireNonNull(getCommand("asbadmin")).setTabCompleter(new SicBoAdminCommand(this));

        TaiXiuCommand taiXiuCommand = new TaiXiuCommand(this);
        Objects.requireNonNull(getCommand("tai")).setExecutor(taiXiuCommand);
        Objects.requireNonNull(getCommand("xiu")).setExecutor(taiXiuCommand);

        getLogger().info(messageManager.color(messageManager.get("plugin-enabled")));
    }

    @Override
    public void onDisable() {
        if (sicBoManager != null) {
            sicBoManager.stop();
        }
        if (discordManager != null) {
            discordManager.stop();
        }
        getLogger().info(messageManager.color(messageManager.get("plugin-disabled")));
    }

    public void reload() {
        reloadConfig();
        messageManager.reload();
        if (sicBoManager != null) {
            sicBoManager.reload();
        }
    }

    public static AllayDoden getInstance() {
        return instance;
    }

    public EconomyManager getEconomyManager() {
        return economyManager;
    }

    public SicBoManager getSicBoManager() {
        return sicBoManager;
    }

    public MessageManager getMessageManager() {
        return messageManager;
    }

    public LinkManager getLinkManager() {
        return linkManager;
    }

    public DiscordManager getDiscordManager() {
        return discordManager;
    }
}
