/*
 * MIT License
 *
 * Copyright (c) 2024 AllayMC
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
package com.allaydoden.plugin.command;

import com.allaydoden.plugin.AllayDoden;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.List;

/** /asbadmin (aliases: allaysicboadmin, dda, dodenadmin). */
public class SicBoAdminCommand implements CommandExecutor, TabCompleter {

    private final AllayDoden plugin;

    public SicBoAdminCommand(AllayDoden plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("doden.admin")) {
            sender.sendMessage(plugin.getMessageManager().color("no-permission"));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                sender.sendMessage(plugin.getMessageManager().color("reloading"));
                plugin.reload();
                sender.sendMessage(plugin.getMessageManager().color("reloaded"));
            }
            case "changestate" -> {
                plugin.getSicBoManager().changeState();
                sender.sendMessage(plugin.getMessageManager().color("admin-changestate",
                        plugin.getMessageManager().ph("state", plugin.getSicBoManager().getState().name())));
            }
            case "settime" -> {
                if (args.length < 2) {
                    sender.sendMessage(plugin.getMessageManager().color("admin-settime-usage"));
                    return true;
                }
                try {
                    int time = Integer.parseInt(args[1]);
                    plugin.getSicBoManager().setTime(time);
                    sender.sendMessage(plugin.getMessageManager().color("admin-settime",
                            plugin.getMessageManager().ph("time", String.valueOf(time))));
                } catch (NumberFormatException e) {
                    sender.sendMessage(plugin.getMessageManager().color("admin-invalid-number"));
                }
            }
            case "setresult" -> {
                if (args.length < 4) {
                    sender.sendMessage(plugin.getMessageManager().color("admin-setresult-usage"));
                    return true;
                }
                try {
                    int d1 = Integer.parseInt(args[1]);
                    int d2 = Integer.parseInt(args[2]);
                    int d3 = Integer.parseInt(args[3]);
                    if (d1 < 1 || d1 > 6 || d2 < 1 || d2 > 6 || d3 < 1 || d3 > 6) {
                        sender.sendMessage(plugin.getMessageManager().color("admin-setresult-invalid"));
                        return true;
                    }
                    plugin.getSicBoManager().setForcedResult(d1, d2, d3);
                    int total = d1 + d2 + d3;
                    sender.sendMessage(plugin.getMessageManager().color("admin-setresult",
                            plugin.getMessageManager().ph("d1", String.valueOf(d1), "d2", String.valueOf(d2), "d3", String.valueOf(d3), "total", String.valueOf(total))));
                } catch (NumberFormatException e) {
                    sender.sendMessage(plugin.getMessageManager().color("admin-setresult-invalid"));
                }
            }
            default -> sendHelp(sender);
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(plugin.getMessageManager().color("admin-help-header"));
        sender.sendMessage(plugin.getMessageManager().color("admin-help-reload"));
        sender.sendMessage(plugin.getMessageManager().color("admin-help-changestate"));
        sender.sendMessage(plugin.getMessageManager().color("admin-help-settime"));
        sender.sendMessage(plugin.getMessageManager().color("admin-help-setresult"));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        if (args.length == 1) {
            completions.addAll(List.of("reload", "changestate", "settime", "setresult"));
        }
        return completions.stream()
                .filter(c -> c.toLowerCase().startsWith(args[args.length - 1].toLowerCase()))
                .toList();
    }
}
